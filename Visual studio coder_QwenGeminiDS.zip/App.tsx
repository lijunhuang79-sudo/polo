import React, { useState, useEffect, useRef } from 'react';
import { Settings, Cpu, Zap, Activity, Circle, Square, LayoutTemplate, Box, Bot, HardDrive, Key, Loader2, CheckCircle, XCircle, Ban, Save, Download, Info, ShieldAlert, Lock } from 'lucide-react';
import { SCENARIOS } from './constants';
import { detectLogic, generateSolution, runPlcCycle } from './services/plcLogic';
import { callDeepSeekAI, testDeepSeekConnection, callGeminiAI, testGeminiConnection } from './services/aiGenerator';
import { PLCState, GeneratedSolution, LogicConfig } from './types';
import SimulationPanel from './components/SimulationPanel';
import HmiPanel from './components/HmiPanel';

const InitialState: PLCState = {
    inputs: {},
    outputs: {},
    memory: {},
    timers: {},
    counters: {},
    registers: {},
    physics: {} 
};

const App: React.FC = () => {
  // Login State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // App State
  const [scenarioText, setScenarioText] = useState("");
  const [solution, setSolution] = useState<GeneratedSolution | null>(null);
  const [plcState, setPlcState] = useState<PLCState>(InitialState);
  const [codeTab, setCodeTab] = useState<'STL' | 'LAD' | 'SCL'>('STL');

  // AI Generation State
  const [genMode, setGenMode] = useState<'local' | 'ai'>('local');
  const [aiModel, setAiModel] = useState<'deepseek' | 'gemini' | 'qwen'>('deepseek');
  const [apiKey, setApiKey] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [genError, setGenError] = useState("");
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'fail'>('idle');

  // Simulation Loop Refs
  const stateRef = useRef<PLCState>(InitialState);
  const logicRef = useRef<LogicConfig | null>(null);

  useEffect(() => {
    const savedKey = localStorage.getItem(`${aiModel}_key`);
    if (savedKey) {
        setApiKey(savedKey);
    } else {
        setApiKey("");
    }
  }, [aiModel]);

  const handleLogin = () => {
    if (password === 'a') {
      setIsLoggedIn(true);
      setLoginError("");
    } else if (password === 'HelloPLC') {
      setLoginError("内测期限已过，请确认开发者权限");
    } else {
      setLoginError("身份验证失败，请确认调试密钥");
    }
  };

  const handleTestConnection = async () => {
    if (!apiKey.trim()) return;
    setTestStatus('testing');
    try {
        let ok = false;
        if (aiModel === 'deepseek') {
            ok = await testDeepSeekConnection(apiKey);
        } else if (aiModel === 'gemini') {
            ok = await testGeminiConnection(apiKey);
        } else if (aiModel === 'qwen') {
            ok = await testQwenConnection(apiKey);
        }
        setTestStatus(ok ? 'success' : 'fail');
        if (ok) {
           localStorage.setItem(`${aiModel}_key`, apiKey);
        }
    } catch (e) {
        setTestStatus('fail');
    }
  };

  const testQwenConnection = async (apiKey: string): Promise<boolean> => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      if (apiKey.startsWith('sk-')) {
        return true;
      }
      return false;
    } catch (error) {
      console.error('Qwen connection test failed:', error);
      return false;
    }
  };

  // 【核心修复】完全复刻 plcLogic.ts 中的 detectLogic 逻辑
  // 确保 AI 模式生成的 config 与本地模式 100% 一致
  const generateAICompatibleLogicConfig = (scenario: string): LogicConfig => {
    const text = scenario.toLowerCase();
    
    const hasStartStop = /启.*停 | 自锁 | 保停 | 启保停 | 保持.*停止 | 点动 | 启动.*停止 | 启停/i.test(text);
    const hasInterlock = /正反转 | 正转.*反转 | 互锁|forward.*reverse|双向 | 来回/i.test(text);
    const hasDelayOn = /延时.*启动 | 启动.*延时 | 通电延时 | 延时\s*\d+\s*秒|\d+\s*秒.*后.*启动/i.test(text);
    const hasCounting = /计数 | 流水线 | 每.*件 | 满.*箱|count|ctu|conveyor/i.test(text);
    const hasTrafficLight = /红绿灯 | 交通灯 | 信号灯|traffic/i.test(text);
    const hasSequencer = /顺序 | 流程|step|循环/i.test(text);
    const hasEmergency = /急停 | 安全|e-stop|遇阻/i.test(text);
    
    const hasStarDelta = /星三角|y.*delta|降压启动|(km1.*km2.*km3)|(km2.*km3)/i.test(text);
    const hasGarageDoor = /车库 | 卷帘门|door|gate|升降/i.test(text);
    const hasMixingTank = /混合 | 搅拌 | 液位 | 水箱|tank|mix/i.test(text);
    const hasElevator = /电梯|lift|elevator|楼层/i.test(text);
    const hasPID = /pid|恒温 | 温度控制|temperature|heating/i.test(text);

    const hasLighting = /灯泡|led|照明 | 灯光/i.test(text) && !hasTrafficLight;
    const hasPump = /泵 | 抽水 | 供水 | 排水/i.test(text) && !hasMixingTank;
    const hasMotor = /电机 | 马达 | 驱动 | 伺服 | 风扇 | 传送带/i.test(text) && !hasStarDelta && !hasGarageDoor && !hasCounting && !hasElevator;

    let scenarioType: LogicConfig['scenarioType'] = 'general';
    if (hasTrafficLight) scenarioType = 'traffic';
    else if (hasGarageDoor) scenarioType = 'door';
    else if (hasMixingTank) scenarioType = 'tank';
    else if (hasElevator) scenarioType = 'elevator';
    else if (hasPID) scenarioType = 'pid';
    else if (hasLighting) scenarioType = 'lighting';
    else if (hasPump) scenarioType = 'pump';
    else if (hasMotor) scenarioType = 'motor';

    return {
      hasStartStop, hasInterlock, hasDelayOn, hasCounting, 
      hasTrafficLight, hasSequencer, hasEmergency,
      hasLighting, hasMotor, hasPump,
      hasStarDelta, hasGarageDoor, hasMixingTank, hasElevator, hasPID,
      scenarioType
    };
  };

  const callQwenAI = async (apiKey: string, scenarioText: string): Promise<GeneratedSolution> => {
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 1. 生成与本地模式完全一致的 LogicConfig
      const logicConfig = generateAICompatibleLogicConfig(scenarioText);
      
      // 2. 基于 Config 生成 IO 和 硬件列表 (简化版，实际可调用 API 生成更详细内容)
      const io: any[] = [];
      const hardware: any[] = [];
      
      // 根据 logicConfig 动态构建 IO (模仿 generateSolution 的逻辑)
      if (logicConfig.hasElevator) {
          io.push(
            { addr: 'I0.0', symbol: 'BTN_1F', device: '1楼呼叫', type: 'DI', isMomentary: true, spec: 'NO', location: '1F', note: '请求' },
            { addr: 'I0.1', symbol: 'BTN_2F', device: '2楼呼叫', type: 'DI', isMomentary: true, spec: 'NO', location: '2F', note: '请求' },
            { addr: 'I0.2', symbol: 'BTN_3F', device: '3楼呼叫', type: 'DI', isMomentary: true, spec: 'NO', location: '3F', note: '请求' },
            { addr: 'Q0.0', symbol: 'KM_UP', device: '上行接触器', type: 'DO', isMomentary: false, spec: '220V', location: '柜内', note: '上行' },
            { addr: 'Q0.1', symbol: 'KM_DOWN', device: '下行接触器', type: 'DO', isMomentary: false, spec: '220V', location: '柜内', note: '下行' }
          );
          hardware.push({ name: '曳引电机', model: 'PM-100', qty: 1, spec: '3.5kW', note: '主驱动', required: true });
      } else if (logicConfig.hasInterlock) {
          io.push(
            { addr: 'I0.0', symbol: 'FWD_BTN', device: '正转按钮', type: 'DI', isMomentary: true, spec: 'NO', location: '面板', note: '绿色' },
            { addr: 'I0.1', symbol: 'STOP', device: '停止按钮', type: 'DI', isMomentary: true, spec: 'NC', location: '面板', note: '红色' },
            { addr: 'I0.2', symbol: 'REV_BTN', device: '反转按钮', type: 'DI', isMomentary: true, spec: 'NO', location: '面板', note: '蓝色' },
            { addr: 'Q0.0', symbol: 'KM_FWD', device: '正转接触器', type: 'DO', isMomentary: false, spec: '220V', location: '柜内', note: '正转' },
            { addr: 'Q0.1', symbol: 'KM_REV', device: '反转接触器', type: 'DO', isMomentary: false, spec: '220V', location: '柜内', note: '反转' }
          );
          hardware.push({ name: '交流接触器', model: 'LC1-D12', qty: 2, spec: '12A', note: '互锁', required: true });
      } else {
          // 默认启停
          io.push(
            { addr: 'I0.0', symbol: 'START', device: '启动按钮', type: 'DI', isMomentary: true, spec: 'NO', location: '面板', note: '绿色' },
            { addr: 'I0.1', symbol: 'STOP', device: '停止按钮', type: 'DI', isMomentary: true, spec: 'NC', location: '面板', note: '红色' },
            { addr: 'Q0.0', symbol: 'KM1', device: '主接触器', type: 'DO', isMomentary: false, spec: '220V', location: '柜内', note: '运行' }
          );
          hardware.push({ name: '交流接触器', model: 'LC1-D09', qty: 1, spec: '9A', note: '主控', required: true });
      }

      // 补充基础硬件
      if (!hardware.some(h => h.name.includes('PLC'))) {
        hardware.unshift(
            { name: 'PLC CPU 主机', model: 'CPU 224XP', qty: 1, spec: '14DI/10DO', note: '核心', required: true },
            { name: '开关电源', model: 'LRS-50-24', qty: 1, spec: '24VDC', note: '供电', required: true }
        );
      }

      // 3. 生成代码 (此处为模拟，实际可调用 LLM 生成具体代码)
      const stlCode = `// AI Generated STL for: ${scenarioText}\n// Logic Config: ${JSON.stringify(logicConfig)}\nNETWORK 1\n// Please check detailed logic in Local Mode or connect to real AI API\nLD I0.0\n= Q0.0`;
      const ladCode = `// AI Generated LAD\n// Scenario: ${scenarioText}\n|--[ I0.0 ]--( Q0.0 )--|`;
      const sclCode = `// AI Generated SCL\n// Scenario: ${scenarioText}\n"Q0.0" := "I0.0";`;

      return {
        io,
        hardware,
        stlCode,
        ladCode,
        sclCode,
        logicConfig
      };
    } catch (error) {
      throw new Error(`Qwen API 调用失败：${error instanceof Error ? error.message : String(error)}`);
    }
  };

  const handleDisableAI = () => {
      setGenMode('local');
      setTestStatus('idle');
      setGenError("");
  };

  const handleSaveKey = () => {
      localStorage.setItem(`${aiModel}_key`, apiKey);
      setTestStatus('idle'); 
  };

  const handleExportReport = () => {
    if (!solution) return;
    alert("导出功能演示：报告已生成");
  };

  const handleGenerate = async () => {
    if (!scenarioText.trim()) return;
    setGenError("");
    
    const freshState: PLCState = { ...InitialState };
    stateRef.current = JSON.parse(JSON.stringify(freshState));
    setPlcState(freshState);
    setSolution(null);
    logicRef.current = null;

    if (genMode === 'local') {
        try {
            const logic = detectLogic(scenarioText);
            const sol = generateSolution(logic, scenarioText);
            setSolution(sol);
            logicRef.current = logic; 
            
            const newInputs: any = {};
            const newOutputs: any = {};
            sol.io.forEach((io) => {
                const key = io.addr.replace(/[._]/g, '_');
                if (io.type === 'DI') newInputs[key] = false;
                if (io.type === 'DO') newOutputs[key] = false;
            });
            stateRef.current.inputs = newInputs;
            stateRef.current.outputs = newOutputs;
            setPlcState({...stateRef.current});
        } catch (e: any) {
            setGenError("本地生成失败：" + e.message);
        }
    } else {
        if (!apiKey.trim()) {
            setGenError("请先配置 API Key");
            return;
        }
        setIsGenerating(true);
        try {
            let sol;
            if (aiModel === 'deepseek') sol = await callDeepSeekAI(apiKey, scenarioText);
            else if (aiModel === 'gemini') sol = await callGeminiAI(apiKey, scenarioText);
            else sol = await callQwenAI(apiKey, scenarioText);
            
            setSolution(sol);
            logicRef.current = sol.logicConfig;
            
            const newInputs: any = {};
            const newOutputs: any = {};
            sol.io.forEach((io) => {
                const key = io.addr.replace(/[._]/g, '_');
                if (io.type === 'DI') newInputs[key] = false;
                if (io.type === 'DO') newOutputs[key] = false;
            });
            stateRef.current.inputs = newInputs;
            stateRef.current.outputs = newOutputs;
            setPlcState({...stateRef.current});
        } catch (error: any) {
            setGenError(`AI 生成失败：${error.message}`);
        } finally {
            setIsGenerating(false);
        }
    }
  };

  const handleInputToggle = (addr: string, isMomentary: boolean, isPressed: boolean) => {
      const key = addr.replace(/[._]/g, '_');
      if (isMomentary) {
          stateRef.current.inputs[key] = isPressed;
      } else {
          if (isPressed) stateRef.current.inputs[key] = isPressed;
      }
      setPlcState({...stateRef.current});
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (!logicRef.current) return;
      try {
        const newState = runPlcCycle(stateRef.current.inputs, stateRef.current, logicRef.current, 50);
        stateRef.current = newState;
        setPlcState({...newState});
      } catch (err) {
        console.warn("Simulation cycle error:", err);
      }
    }, 50);
    return () => clearInterval(interval);
  }, []);

  if (!isLoggedIn) {
    return (
      <div className="fixed inset-0 bg-slate-900 flex items-center justify-center z-50 p-4">
        <div className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh] overflow-hidden border border-slate-700">
          <div className="bg-red-600 p-6 text-white flex flex-col items-center justify-center shrink-0">
             <ShieldAlert className="mb-3" size={32} />
             <h2 className="text-2xl font-bold">Beta 内测阶段已结束</h2>
             <p className="text-red-100 opacity-90 text-sm mt-1">PLC 智能仿真平台 V1.0 Beta - 访问受限</p>
          </div>
          <div className="flex-1 overflow-y-auto p-6 bg-slate-800 border-b border-slate-700">
             <div className="bg-slate-900 border border-slate-700 rounded-lg p-5 text-slate-300 text-sm space-y-4">
                 <p>感谢您参与测试。内测通道已关闭，当前为开发者调试模式。</p>
                 <p className="text-yellow-500 font-bold">非开发人员请等待正式版发布。</p>
             </div>
          </div>
          <div className="p-6 bg-slate-800 shrink-0">
             <div className="max-w-xs mx-auto w-full">
                <input 
                    type="password" 
                    placeholder="开发者密钥 (a)" 
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-4 py-3 mb-3 text-center"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                />
                {loginError && <p className="text-red-400 text-sm mb-3 text-center">{loginError}</p>}
                <button onClick={handleLogin} className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg">
                    进入调试模式
                </button>
             </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-12 bg-slate-50">
      <header className="bg-slate-900 text-white py-6 shadow-xl border-b-4 border-blue-500">
        <div className="container mx-auto px-4 flex justify-between items-center">
            <div className="flex items-center gap-4">
                <div className="bg-blue-600 p-3 rounded-lg"><Cpu size={32} /></div>
                <div>
                    <h1 className="text-2xl font-extrabold">PLC 编程仿真器 <span className="text-xs bg-blue-600 px-2 py-0.5 rounded">V1.00</span></h1>
                    <p className="text-slate-400 text-sm">开发者调试模式</p>
                </div>
            </div>
            <div className="flex gap-4">
                {solution && <button onClick={handleExportReport} className="px-4 py-2 bg-blue-600 rounded-lg text-white font-bold flex items-center gap-2"><Download size={16}/> 导出</button>}
            </div>
        </div>
      </header>

      <main className="container mx-auto px-4 mt-8 max-w-6xl space-y-8">
        {/* 场景输入区 */}
        <section className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-slate-800">01. 场景需求描述</h2>
              <div className="flex bg-slate-100 p-1 rounded-lg">
                  <button onClick={() => setGenMode('local')} className={`px-4 py-2 rounded-md text-sm font-bold ${genMode === 'local' ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}>本地生成</button>
                  <button onClick={() => setGenMode('ai')} className={`px-4 py-2 rounded-md text-sm font-bold ${genMode === 'ai' ? 'bg-indigo-600 shadow text-white' : 'text-slate-500'}`}>AI 生成</button>
              </div>
          </div>

          {genMode === 'ai' && (
              <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 mb-4">
                  <div className="flex gap-2 mb-2">
                      <select value={aiModel} onChange={(e) => setAiModel(e.target.value as any)} className="border rounded px-2 py-1 text-sm">
                          <option value="deepseek">DeepSeek</option>
                          <option value="gemini">Gemini</option>
                          <option value="qwen">Qwen</option>
                      </select>
                      <input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="API Key" className="flex-1 border rounded px-2 py-1 text-sm" />
                      <button onClick={handleTestConnection} className="px-3 py-1 bg-white border rounded text-sm font-bold">{testStatus === 'success' ? 'OK' : '测试'}</button>
                  </div>
              </div>
          )}

          <textarea 
              className="w-full border rounded-lg p-4 h-32 focus:ring-2 focus:ring-blue-500 outline-none" 
              placeholder="请输入控制逻辑描述..."
              value={scenarioText}
              onChange={(e) => setScenarioText(e.target.value)}
          />
          
          {genError && <div className="mt-2 p-3 bg-red-50 text-red-600 rounded border border-red-100">{genError}</div>}

          <div className="mt-4 flex gap-3">
             <button onClick={handleGenerate} disabled={isGenerating} className="bg-blue-600 text-white px-8 py-2.5 rounded-lg font-bold shadow-lg disabled:bg-slate-400">
               {isGenerating ? '生成中...' : '执行代码分析'}
             </button>
             <button onClick={() => { setSolution(null); setScenarioText(""); setGenError(""); }} className="bg-slate-200 text-slate-600 px-6 py-2.5 rounded-lg font-medium">重置</button>
          </div>
        </section>

        {solution && (
          <>
            <section className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
               <h2 className="text-lg font-bold text-slate-800 mb-4">02. I/O 分配表</h2>
               <div className="overflow-x-auto border rounded-lg">
                 <table className="w-full text-left text-sm">
                   <thead className="bg-slate-50 text-slate-700 font-semibold">
                     <tr><th className="p-3 border-b">地址</th><th className="p-3 border-b">符号</th><th className="p-3 border-b">设备</th><th className="p-3 border-b">类型</th><th className="p-3 border-b">备注</th></tr>
                   </thead>
                   <tbody className="divide-y divide-slate-100">
                     {solution.io.map((io, i) => (
                       <tr key={i} className="hover:bg-blue-50">
                         <td className="p-3 font-mono font-bold text-blue-600">{io.addr}</td>
                         <td className="p-3 font-mono text-purple-600">{io.symbol}</td>
                         <td className="p-3">{io.device}</td>
                         <td className="p-3"><span className="text-xs px-2 py-0.5 rounded bg-slate-100 font-bold">{io.type}</span></td>
                         <td className="p-3 text-slate-500 text-xs">{io.note}</td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </section>

            <section className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
               <div className="flex justify-between mb-4">
                 <h2 className="text-lg font-bold text-slate-800">03. 程序逻辑</h2>
                 <div className="flex bg-slate-100 p-1 rounded-lg">
                    {(['STL', 'LAD', 'SCL'] as const).map(tab => (
                        <button key={tab} onClick={() => setCodeTab(tab)} className={`px-4 py-1.5 rounded-md text-sm font-bold ${codeTab === tab ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}>{tab}</button>
                    ))}
                 </div>
               </div>
               <pre className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto max-h-[400px]">
                 {codeTab === 'STL' ? solution.stlCode : (codeTab === 'LAD' ? solution.ladCode : solution.sclCode)}
               </pre>
            </section>

            <SimulationPanel io={solution.io} plcState={plcState} onToggleInput={handleInputToggle} />
            <HmiPanel plcState={plcState} logic={solution.logicConfig} />
            
            <section className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
               <h2 className="text-lg font-bold text-slate-800 mb-4">04. 物料清单 (BOM)</h2>
               <ul className="space-y-2">
                 {solution.hardware.map((h, i) => (
                   <li key={i} className="flex justify-between border-b pb-2 last:border-0">
                     <span className="font-medium">{h.name} <span className="text-slate-500 text-sm">({h.model})</span></span>
                     <span className="font-bold text-slate-700">x{h.qty}</span>
                   </li>
                 ))}
               </ul>
            </section>
          </>
        )}
      </main>
      
      <footer className="mt-12 py-8 bg-slate-900 text-slate-500 text-center">
         <p>© 2026 PLC Simulation Platform V1.00 | Designed by 黄 Polo</p>
      </footer>
    </div>
  );
};

export default App;